# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Store::Application.config.secret_token = '0539f8ffe127e02a2e53802f5b1a4700b055b5f7300d48b20d4e9adeed97fb4e538d6d27e00e3bd297dc15dd1f255bee0afcfcf346771694374729ffcafe0efe'
