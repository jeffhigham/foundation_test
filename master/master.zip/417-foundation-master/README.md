# RailsCasts Episode #417: Foundation

http://railscasts.com/episodes/417-foundation

Requires Ruby 1.9.2 or higher.


### Commands used in this episode

```
rails new store
cd store
rails g scaffold product name price:decimal --skip-stylesheets
rake db:migrate
bundle
rails g foundation:install
```
